<?php

namespace App\Http\Requests;

class UpdateTaskRequest extends StoreTaskRequest
{
}
